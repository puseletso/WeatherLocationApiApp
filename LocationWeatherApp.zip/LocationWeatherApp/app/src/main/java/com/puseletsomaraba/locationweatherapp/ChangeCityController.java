package com.puseletsomaraba.locationweatherapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class ChangeCityController extends AppCompatActivity {

    private EditText queryET;
    private ImageButton backButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //conect class to xml layout
        setContentView(R.layout.change_city_layout);
        init();

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        queryET.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

             String city=queryET.getText().toString();
             Intent intent=new Intent(ChangeCityController.this,MainActivity.class);
             intent.putExtra("City",city);
             startActivity(intent);


                return false;
            }
        });



    }

    private void init()
    {
        queryET=findViewById(R.id.queryET);
        backButton=findViewById(R.id.backButton);
    }
}
